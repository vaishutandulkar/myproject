import React, { useState } from "react";


function Dummy()
{
return (
    <h1>hello dummy</h1>
)

}


export default Dummy;
